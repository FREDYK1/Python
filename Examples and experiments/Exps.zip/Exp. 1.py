import glob

txtFiles = glob.glob("*.txt")

for filepath in txtFiles:
    with open(filepath, 'r') as file:
        print(file.read())