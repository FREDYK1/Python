import shutil

shutil.make_archive("Exps", "zip")