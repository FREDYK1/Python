password = input("What is your password: ")

while password != "FREDYK1":
    print("Password not Correct")
    password = input("What is your password: ")

print("Password Correct")

